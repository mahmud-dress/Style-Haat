import React from "react";
import { ShoppingCart, Facebook, Phone } from "lucide-react";

export default function DressShopHome() {
  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-pink-700">FashionEase</h1>
        <p className="text-pink-500">আপনার পছন্দের পোশাক এখন অনলাইনে</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="bg-white rounded-xl shadow-lg hover:shadow-pink-200">
            <img
              src={`https://source.unsplash.com/300x300/?dress,model,${i}`}
              alt="Dress"
              className="rounded-t-xl w-full h-60 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold text-pink-700">সুন্দর জামা #{i + 1}</h2>
              <p className="text-sm text-gray-500">দাম: ৳৮৫০</p>
              <div className="mt-3 flex justify-between items-center">
                <button className="bg-pink-600 text-white px-3 py-1 rounded flex items-center text-sm">
                  <ShoppingCart className="w-4 h-4 mr-1" /> অর্ডার করুন
                </button>
                <div className="flex gap-2">
                  <a href="https://m.me/yourshop" target="_blank" rel="noopener noreferrer">
                    <Facebook className="text-blue-600" />
                  </a>
                  <a href="tel:+8801XXXXXXXXX">
                    <Phone className="text-green-600" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <footer className="mt-10 text-center text-sm text-gray-500">
        © 2025 FashionEase. সব অধিকার সংরক্ষিত।
      </footer>
    </div>
  );
}
